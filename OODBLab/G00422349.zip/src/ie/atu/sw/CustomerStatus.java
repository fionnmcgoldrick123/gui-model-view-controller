package ie.atu.sw;

public enum CustomerStatus {
	  LEAD,
	  ONETIME,
	  RECURRING,
	  FORMER;
}
package ie.atu.sw;

public record Address (String street, String city, County county) {
}
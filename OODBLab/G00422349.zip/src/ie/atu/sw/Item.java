package ie.atu.sw;

public record Item (String number, String description, int quantity, float price) {
}
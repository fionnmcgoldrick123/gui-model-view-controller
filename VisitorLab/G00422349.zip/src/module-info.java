/**
 * 
 */
/**
 * 
 */
module ie.gmit.sw {
    requires javafx.controls;
    requires javafx.base;
    requires javafx.graphics;

    exports ie.atu.sw;
}